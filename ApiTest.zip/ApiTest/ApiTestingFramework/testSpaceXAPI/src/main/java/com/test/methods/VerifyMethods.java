package com.test.methods;
import io.restassured.response.Response;
import org.hamcrest.Corematchers;
import org.junit.Assert;
import java.util.logging.*;
import static org.assertj.core.api.Assertions.asserThat;


public class VerifyMethods {

    public static void verifyStatusCode(Response response){
        try {
            int statusCode = response.statusCode();
            assertThat(statusCode).isEqualTo(200);
        }
        catch (Exception e){
            Logger.getLogger("test").log(Level.INFO, "FAIL", e);
        }
    }

    public static <T> void verifyContains(String actual, String expected){
        try {
            Assert.assertThat(actual, CoreMatchers.containsString(expected));
        }
        catch (Exception e){
            Logger.getLogger("test").log(Level.INFO, "FAIL", e);
        }
    }
}
