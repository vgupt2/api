package com.test.methods;
import static io.restassured.RestAssured.given;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import java.util.logging.*;

import java.util.logging.Logger;

public class RestAPI {
    public static Response getGetResponse(String url, String action) {
        Response response = null;
        try{
            response = given().
                    contentType(ContentType.Json).
                    when().get(url + "/" + action);
        }
        catch (Exception e){
            Logger.getLogger("test").log(level.INFO,"FAIL",e);
        }
        return response;
    }
}
