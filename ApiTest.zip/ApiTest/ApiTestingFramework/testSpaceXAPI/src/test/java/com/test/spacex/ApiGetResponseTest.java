package com.test.spacex;

import com.test.methods.*;
import com.thoughworks.gauge.*;
import static io.restassured.path.json.JsonPath;
import static io.restassured.response.Response;
import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;
import java.util.*;
import java.util.logging.Logger;


public class ApiGetResponseTest {

    @Step("* Get Response from API <APIURL> with Expected Status_Code <200>")
    public void getAPi(String ApiURL, int Status_Code){
        Resposne resposne = null;
        try
        {
            response = given.when().get(ApiURL);
            int resStatus_Code = resposne.getStatusCode();
            Gauge.writemessage("API URL :" + ApiURL);
            Gauge.writemessage("Response Status :" +resStatus_Code);
            VerifyMethods.verifyContains(response);
        }
        catch (Exception e){
            Logger.getLogger("test").log(level.INFO,"FAIL",e);
        }
    }

    @Step("* Get Response from API <APIURL> for Response Properties <rocket> with Expected Response value <true>")
    public void getAPiResponsevalue(String ApiURL, String ResponseProperties, String ExpectedResponseValue){
        Resposne resposne = null;
        try
        {
            response = given.when().get(ApiURL);
            int resStatus_Code = resposne.getStatusCode();
            Gauge.writemessage("API URL :" + ApiURL);
            Gauge.writemessage("Response Status :" +resStatus_Code);
            VerifyMethods.verifyContains(response);
            String ActualResponseValue = resposne.jsonPath().getString(ResponseProperties);
            Gauge.writemessage("Actual Response :" + ActualResponseValue);
            Gauge.writemessage("Expected Response :" + ExpectedResponseValue);
            VerifyMethods.verifyContains(ActualResponseValue, ExpectedResponseValue);
        }
        catch (Exception e){
            Logger.getLogger("test").log(level.INFO,"FAIL",e);
        }
    }

    @Step("* Get Response from BASEURL <APIURL> with Action <launches> for Response Properties <rocket> with Expected Response value <true>")
    public static String [] getAPiResponseValueArray(String BaseURL, String Action, String ResponseProperties, String ExpectedResponseValue){
        Resposne resposne = null;
        try
        {
            Map<String, Object> mappingData = new HashMap<String, Object>();
            response = given.when().get(ApiURL);
            int resStatus_Code = resposne.getStatusCode();
            Gauge.writemessage("API URL :" + ApiURL);
            Gauge.writemessage("Response Status :" +resStatus_Code);
            assertThat(StausCode).isEqualto(200);
            Jsonpath jsonPathEvaluator = resposne.jsonPath();
            String ActualResponseValue = jsonPathEvaluator.getString(ResponseProperties);
            Gauge.writemessage("Actual Response :" + ActualResponseValue);
            Gauge.writemessage("Expected Response :" + ExpectedResponseValue);
            VerifyMethods.verifyContains(ActualResponseValue, ExpectedResponseValue);
            return new String[]{ActualResponseValue};
        }
        catch (Exception e){
            Logger.getLogger("test").log(level.INFO,"FAIL",e);
        }
    }

}
